<?php

class Validation{
    
    //escape unicode & url validator
    private $allowed_domains = ["aol.com", "att.net", "comcast.net", "facebook.com", "gmail.com", "gmx.com", "googlemail.com",
    "google.com", "hotmail.com", "hotmail.co.uk", "mac.com", "me.com", "mail.com", "msn.com",
    "live.com", "sbcglobal.net", "verizon.net", "yahoo.com", "yahoo.co.uk","sha.edu.eg"];
    private $black_list = ['/','<','>','\\',','];
    private $email    = NULL;
    private $password = NULL;
    private $password_again = NULL;
    private $minLength = 8;
    private $MaxLength = 32;
    private $yearNumber = ['0','1','2','3','4'];
    private $Empty_field = 'This Field Can not be empty';
    private $specialist = ['Communication','Chemistry','Bio-Medical','Civilian'];
    private $special;
    public function __construct(){
        header('cache-control:no-cache,no-store,max-age = 0, must-revalidate');
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('X-XSS-Protection: 1; mode=block');
        header("content-security-policy: script-src 'self' https://www.google-analytics.com");
        //test the CSP
    }
    public function validating_email($email){
        $this->email = $email;
        $errors = NULL;
       if(!empty($this->email)){
            if(filter_var($this->email,FILTER_SANITIZE_EMAIL)){
                if(filter_var($this->email,FILTER_VALIDATE_EMAIL)){
                    $validating = explode('@',$this->email);
                    if(in_array($validating[1], $this->allowed_domains)){
                    
                        if(strlen($validating[0])>= $this->minLength){
                            if(strlen($validating[0]) <= $this->MaxLength){
                                if (preg_match("/^[a-zA-Z0-9.]*$/i",$validating[0])) {
                                    return true;
                                }else{
                                    $errors[] = 'Email should only contain of letters and dot only';
                                }
                            }else{
                                $errors[] = "Email should only contain of maximum $this->MaxLength letters and numbers only";
                            }
                        }else{
                            $errors[] = "Email should only contain of at least minimum $this->minLength letters and numbers";
                        }
                    }else{
                        $errors[] = 'This Domain Does not exist';
                    }
                }else{
                    $errors[] = 'Invalid Email Address';
                }
            }else{
                $errors[] = 'Invalid Email Address';
            }
        }else{
            $errors[] = $this->Empty_field;
        }   
       if(isset($errors)){
        return ['false',$errors[0]]; 
        
       }
    }
    public function validating_password($password){
        $this->password = $password;
        $Validated = NULL;
        $str_split = str_split($this->password,1);
        $i = 0;
        if(empty($this->password)){
            $Validated = ['false',$this->Empty_field];
        }else{
            switch ($this->password) {
           
                case(is_array($str_split)):
                    foreach($str_split as $key => $value){
                        ++$i;
                        if(in_array($value,$this->black_list)){
                            $Validated = ['false','Forbidden Characters have been set'];
                            break 2;
                        }else{
                            if((count(array_keys($str_split))) == $i ){
                                if(preg_match("/^(?=^.{8,32}$)((?=.*\d)(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/",$this->password)){
                                   $Validated = ['true',$this->password];  
                                }else{
                                    $Validated = ['false',"password should contain of 8 to 32 characters, one Uppercase , One Lowercase, one number and at least one special character"]; 
                                } 
                            }
                        }
                    }
                break;
            }
        }
        
        return $Validated;
    }
    public function check_password($password_again){
        
        $this->password_again = $password_again;
      
        return (!empty($this->password_again)) ? (($this->password_again === $this->validating_password($this->password)[1]) ?: ['false','This password does not match']) : ['false',$this->Empty_field];
    }
   public function validating_alnum($alnum){
        return (!empty($alnum)) ? ((htmlentities(ctype_alnum($alnum),ENT_QUOTES,'UTF-8') && strlen($alnum) >= $this->minLength && strlen($alnum) <= $this->MaxLength ) ?: ['false','This Field should only contain of letters and numbers , 8-32 characters']) : ['false',$this->Empty_field];
   }
   public function validating_num($num){
        return (!empty($num)) ? ((htmlentities(ctype_digit($num),ENT_QUOTES,'UTF-8')  && strlen($num) >= $this->minLength && strlen($num) <= $this->MaxLength ) ?: ['false','This Field should only contain of numbers , 8-32 characters']) : ['false',$this->Empty_field];
    }
    public function validating_year($num){
        return (!empty($num)) ? ((htmlentities(ctype_digit($num),ENT_QUOTES,'UTF-8')  && (strlen($num) === 1) && in_array($num,$this->yearNumber)) ?: ['false','This Field should only contain of numbers , 1 character representing your year (0-4) where 0 is Preparatory']) : ['false',$this->Empty_field];
    }
    public function validating_Specialty($specialty){
        $this->special = $specialty;
        
        return (!empty($this->special)) ? (htmlentities(ctype_alpha($this->special),ENT_QUOTES,'UTF-8') && in_array($this->special,$this->specialist)) ?: ['false','Invalid Specialty. Communication , Civilian , Chemistry & Bio-Medical Are Available '] : ['false',$this->Empty_field];
    }
    public function validating_string($string){
        return (!empty($string)) ? ((htmlentities(preg_match('/^[a-z0-9]+$/i', $string),ENT_QUOTES,'UTF-8') && strlen($string) >= 3 && strlen($string) <= 15) ?: ['false','This field should only contain letters , 3-15 characters']) : ['false',$this->Empty_field];
    }
    public function validating_username($username){
       return (!empty($username)) ? (htmlentities(preg_match('/^[A-Za-z0-9]+(?:[_-][A-Za-z0-9]+)*$/',$username)) && strlen($username) >= $this->minLength && strlen($username) <= $this->MaxLength) ?: ['false','This Field Should only contain of letters,numbers and underscore only , 8-32 charcters'] : ['false',$this->Empty_field];
    }
    public function validating_reason($string){
        return (!empty($string)) ? ((htmlentities(preg_match('/^[A-Za-z0-9]+(?:[ _-])+$/i', $string),ENT_QUOTES,'UTF-8') && strlen($string) >= 8 && strlen($string) <= 254) ?: ['false','This field should only contain letters, numbers , underscore, hyphen,whitespaces and 8-254 characters']) : ['false',$this->Empty_field];
    }
    public function validating_duration($duration){
        return (!empty($duration)) ? ((htmlentities(ctype_digit($duration),ENT_QUOTES,'UTF-8')) && strlen($duration) >= 2 && strlen($duration) <= 3 && $duration >= 20 && $duration <= 360) ?: ['false','This Field should only contain of numbers, 2-3 numbers , minimum 20 and maximum 360'] : ['false',$this->Empty_field]; 
    }
    public function validating_PIN($pin){
        return (!empty($pin)) ? ((htmlentities(ctype_digit($pin),ENT_QUOTES,'UTF-8')) && strlen($pin) === 5) ?: ['false','This Field should only contain of numbers, 5 numbers'] : ['false',$this->Empty_field]; 
    }
}



