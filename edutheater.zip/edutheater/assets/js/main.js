function save(){
	var content = document.getElementById("content").value;
	var user_id = document.getElementById("user_id").value;
	var x = document.getElementById("result");
	var xhttp;
	if(content != ''){
		xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
		if (xhttp.readyState == 4 && xhttp.status == 200) {
			document.getElementById("change").innerHTML = "";
			x.innerHTML = xhttp.responseText+x.innerHTML;
			document.getElementById("content").value = '';
		}else{
			document.getElementById("change").innerHTML = "";
			x.innerHTML = '<p id="change" style="margin-left:50%;"><i class="fa fa-spinner fa-pulse fa-lg fa-fw"></i><span class="sr-only">Loading...</span></p>'+x.innerHTML;	
		}
		};
		xhttp.open("GET", "save.php?content="+content+"&user_id="+user_id, true);
		xhttp.send();
		}

}
function save_comment(id_post){
	var content_comment = document.getElementById(id_post+"comment").value;
	var user_id = document.getElementById("user_id").value;
	var x = document.getElementById(id_post+"result");
	var xhttp;
	if(content != ''){
		xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
		if (xhttp.readyState == 4 && xhttp.status == 200) {
			document.getElementById("change").innerHTML = "";
			x.innerHTML += xhttp.responseText;
			document.getElementById(id_post+"comment").value = '';
		}else{
			document.getElementById("change").innerHTML = "";
			//x.innerHTML += '<div id="change" style="margin-left:50%;"><i class="fa fa-spinner fa-pulse fa-lg fa-fw"></i><span class="sr-only">Loading...</span></div>';	
		}
		};
		xhttp.open("GET", "save.php?content_comment="+content_comment+"&user_id="+user_id+"&postid="+id_post, true);
		xhttp.send();
		}

}