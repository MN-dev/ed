<?php

class Admin {
    public $subject;
    public $id;
    private $username,$password;
    const CREDENTIALS = [
        'username'      => 'root',
        'password'      => '',
        'dbname'        => 'edutheater',
        'host'          => 'localhost'
    ];
    protected  static $pdo = null;
        
    public function connection(){
        try{
            if(NULL === self::$pdo){
            self::$pdo = new \PDO('mysql:host=' . self::CREDENTIALS['host'] . ';dbname=' . self::CREDENTIALS['dbname'], self::CREDENTIALS['username'], self::CREDENTIALS['password']);
            self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
            }
            return self::$pdo;
        }catch(PDOException $e){
            die($e->getMessage());
        }
    }
     public function makeAdmin($username){
        $stmt = $this->connection()->prepare('UPDATE users set is_admin = 1 WHERE username = :username OR email = :username');
        $stmt->execute([
            ':username' => $username,
            
        ]);
        return ($stmt->rowCount()) ?: false;
    }
    public function makeManager($username){
        $stmt = $this->connection()->prepare('UPDATE users SET is_admin = 2 WHERE username = :username OR email = :username');
        $stmt->execute([
            ':username' =>$username,
            
        ]);
        return ($stmt->rowCount()) ?: false;

    }
    public function checknumofbans($username){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE username = :username OR email = :username AND is_admin = 1');
        $stmt->execute([
            ':username' => $username
            
        ]);
        if($stmt->rowCount()){
              
                
            foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as  $key => $value){
                
                if($value['num_of_ban'] <= 3){
                    return true;
                }
            }

        }
        return false;
       
    }
    public function PlusoneToBan($username){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE username = :username or email = :username AND is_admin = 1');
        $stmt->execute([
            ':username' => $username
        ]);
        if($stmt->rowCount()){
            foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $key => $value){
                $stmt = $this->connection()->prepare("UPDATE users SET num_of_ban = {$value['num_of_ban']} + 1 WHERE username = :username OR email =:username");
                $stmt->execute([
                    ':username' => $username
                ]);
                if($stmt->rowCount()){
                    return true;
                    break;
                }

            }
            
        }
        return false;
    }
    public function checkifbanned($username){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE username = :username OR email = :username AND active = 0');
        $stmt->execute([

            ':username' => $username
        ]);
        if($stmt->rowCount()){
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $key => $value) {
                if($value['ban_time'] > time()){
                    return ['true','You are Still Banned, If you Think That was wrong, Please Contact An Admin'];
                }
            }
        }
        return false;
    }
    public function DowngradeManager($username){
        $stmt = $this->connection()->prepare('UPDATE users SET is_admin = 0 WHERE username = :username OR email = :username');
        $stmt->execute([
            ':username' =>$username
        ]);
        return ($stmt->rowCount()) ?: false;
    }
    public function isAdmin($username){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE username = :username OR email = :username AND is_admin = 1');
        $stmt->execute([
            ':username' => $username
        ]);
        if($stmt->rowCount()){
            return true;
        }
        return false;
    }
   
    public function getName($username){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE username = :username OR email = :username AND is_admin > 0');
        $stmt->execute([
            ':username' => $username
        ]);
        return ($stmt->rowCount()) ? $stmt->fetch(PDO::FETCH_ASSOC) : false;
    }
    public function isManager($username){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE username = :username OR email = :username AND is_admin = 2');
        $stmt->execute([
            ':username' => $username
        ]);
        return ($stmt->rowCount()) ?: false;
    }
    public function listOnlineAdmins(){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE is_admin = 1 and is_logged = 1 and active = 1');
        $stmt->execute();
        return ($stmt->rowCount()) ? $stmt->fetchAll(PDO::FETCH_ASSOC) : false;
    }
    public function listOnlineUsers(){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE is_admin = 0 and is_logged = 1 and active = 1');
        $stmt->execute();
        return ($stmt->rowCount()) ? $stmt->fetchAll(PDO::FETCH_ASSOC) : false;
    }
    public function listActiveUsers(){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE is_admin = 0 AND active = 1');
        $stmt->execute();
        return ($stmt->rowCount()) ? $stmt->fetchAll(PDO::FETCH_ASSOC) : false;
    }
   
    public function listManagerUsers(){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE is_admin = 2 AND active = 1');
        $stmt->execute();
        return ($stmt->rowCount()) ? $stmt->fetchAll(PDO::FETCH_ASSOC) : false;
    }
    public function listDeactivatedUsers(){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE is_admin = 0 AND active = 0');
        $stmt->execute();
        return ($stmt->rowCount()) ? $stmt->fetchAll(PDO::FETCH_ASSOC) : false;
    }
    public function isActive($username){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE username = :username AND active = 1 AND is_admin = 0');
        $stmt->execute([
            ':username' => $username
        ]);
        if($stmt->rowCount()){
            return ['true','User is currently Activated'];
        }
        return ['false','User is not activated'];
    }
    public function deactivate($username){
        $stmt = $this->connection()->prepare('UPDATE users SET active = 0 WHERE username = :username AND is_admin = 0');
        $stmt->execute([
            ':username' => $username
        ]);
        if($stmt->rowCount()){
            return ['true','User Has been De-activated Successfully'];
        }
        return ['false','You Can not De-activate An Admin'];
    }
    
}
/*$A = new Admin;
if($A->checknumofbans('Mohammed_osama')){
    $A->PlusoneToBan('Mohammed_osama');
}else{
    echo ' you can not deactivate anyone';
}

var_dump($A->checkifbanned('Mohammed_osama31'));*/