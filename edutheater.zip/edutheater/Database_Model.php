<?php
 abstract class DB {


    const CREDENTIALS = [
        'username' => 'root',
        'password'  =>'',
        'dbname'    => 'edutheater',
        'host'      =>'localhost'
    ];
    private static $_instance = null;
    public $_pdo, 
    $_query, 
    $_error = false,
    $_results,
    $_count = 0;

    public function connection(){
        try {
            $this->_pdo= new PDO('mysql:host='. self::CREDENTIALS['host'] .';dbname='. self::CREDENTIALS['dbname'] , self::CREDENTIALS['username'] ,self::CREDENTIALS['password']);
        }catch (PDOException $o){
            die($o->getMessage());
        }
       
    }
   
    public function query($sql,$params = []){
        $this->_error = false;
        $x = 1;
        if($this->_query = $this->_pdo->prepare($sql)){
            if(count($params)){
                foreach($params as $param){
                    $this->_query->bindValue($x,$param);
                    $x++;
                }
            if($this->_query->execute()){
                
                $this->_results = $this->_query->fetchAll(PDO::FETCH_OBJ);
                $this->_count   = $this->_query->rowCount();
            }else{
                $this->_error = true;
            }
            }
        }
        //returning the objects that we are working with so we allow the changes to happen
        return $this;
    }
    private function action($action,$table,$where=[]){
        //SELECT * from users where username = Flare 
        // SELECT * -> $action 
        // users -> $table
        // username -> represents the first field in the array 
        // = -> represents the second field in the array 
        // Flare -> represents the third field in the array 
        
        if(count($where) === 3){

            //extracting the data from an array , or converting the data from an array to string
            $operators = ['=','>','<','>=','<='];
            $field     =    $where[0];
            $operator  =    $where[1];
            $value     =    $where[2];
            if(in_array($operator,$operators)){
                $sql="{$action} FROM {$table} WHERE {$field} {$operator} ? ";
                if(!$this->query($sql,array($value))->error()){
                    return $this;
                    //return these data if it happens succesfully and no errors
                }
            }elseif(count($where) === 6){
                
                $operators = ['=','>','>=','<='];
                $field     = $where[0];
                $operator  = $where[1];
                $value     = $where[2];
                $field1    = $where[3];
                $operator1 = $where[4];
                $value1    = $where[5];
                if(in_array($operator,$operators) && in_array($operator1,$operators)){
                    $sql = "{$action} FROM {$table} WHERE {$field} {$operator} ? AND {$field1} {$operator1} ? ";
                    if(!$this->query($sql,[$value,$value1])){
                        return $this;
                    }
                }
            }else{
                $sql = "{$action} FROM {$table}";
                return $this;
            }
        }
        return false;
    }
    public function get($table,array $where){

        return $this->action('SELECT *' ,$table,$where);
    }
    public function delete($table,$where){

        return $this->action('DELETE' ,$table,$where);
    }
    public function insert($table,$field=[]){
        if(count($field)){
            $keys   = array_keys($field);
            $values = null;
            $x      =  1;
            foreach($field as $fields){
                $values .='?';
                if($x < count($field)){
                    $values .=', ';
                
                }
                $x++;
            }
        
            $sql    = "INSERT INTO {$table}  (`".implode('`,`', $keys) ."`)  VALUES ({$values})";
                
            if(!$this->query($sql,$field)->error()){
                return true;
            }
        }
        return false;
    }
    public function update($table,$id,$fields){
        $set    = '';
        $x      =  1;
        foreach($fields as $name => $value){
            $set .="{$name} = ?";
            if($x < count($fields)){
            $set .= ', ';
            }
            $x++;
        }

        $sql    = "UPDATE {$table} SET {$set} WHERE id={$id}";
        if(!$this->query($sql,$fields)->error()){
            return true;
        }
        return false;
    }
    public function results(){
        return $this->_results;
    }
    public function first(){
        return $this->results()[0];
    }

    public function error(){
        return $this->_error;

    }
    public function count(){
        return $this->_count;
    }
}