<?php

class Operations{
    public $subject;
    public $id;
    private $username,$password;
    const CREDENTIALS = [
        'username'      => 'root',
        'password'      => '',
        'dbname'        => 'edutheater',
        'host'          => 'localhost'
    ];
    protected  static $pdo = null;
        
    public function connection(){
        try{
            if(NULL === self::$pdo){
            self::$pdo = new \PDO('mysql:host=' . self::CREDENTIALS['host'] . ';dbname=' . self::CREDENTIALS['dbname'], self::CREDENTIALS['username'], self::CREDENTIALS['password']);
            self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
            }
            return self::$pdo;
        }catch(PDOException $e){
            die($e->getMessage());
        }
    }
    public function checkUserToDeactivate($id,$email,$username,$duration,$ban_time,$pin_code,$reason){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE id =:id AND email = :email');
        $stmt->execute([
            ':id' => $id,
            ':email' => $email
        ]);
        if($stmt->rowCount()){
            $stmt = $this->connection()->prepare('UPDATE users SET active = 0, deactivated_by = :username,duration = :duration ,ban_time = :ban_time,pin_code = :pin_code, reason = :reason WHERE id = :id');
            $stmt->execute([
                ':id' => $id,
                ':username' => $username,
                ':duration' => $duration,
                ':ban_time' => $ban_time,
                ':pin_code' => $pin_code,
                ':reason'   => $reason
            ]);
            return ['true','User has been Deactivated Successfully'];
        }
        return ['false','Please Stop messing around & Let The Hidden Fields'];
        
    }
    public function checkUserToUpgrade($id,$email){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE id =:id AND email = :username OR username = :username');
        $stmt->execute([
            ':id' => $id,
            ':username' => $email
        ]);
        if($stmt->rowCount()){
            $stmt = $this->connection()->prepare('UPDATE users SET is_admin = 2 WHERE id = :id');
            $stmt->execute([
                ':id' => $id
            ]);
            return ['true','User has been Upgraded Successfully'];
        }
        return ['false','Please Stop messing around & Let The Hidden Fields'];
        
    }
    public function checkUserToDowngrade($id,$email){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE id =:id AND email = :username OR username = :username');
        $stmt->execute([
            ':id' => $id,
            ':username' => $email
        ]);
        if($stmt->rowCount()){
            $stmt = $this->connection()->prepare('UPDATE users SET is_admin = 0 WHERE id = :id');
            $stmt->execute([
                ':id' => $id
            ]);
            return ['true','User has been Downgraded Successfully'];
        }
        return ['false','Please Stop messing around & Let The Hidden Fields'];
        
    }
    public function checkUserToActivate($id,$email,$activated_by,$pin_code,$reason){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE id =:id AND email = :email AND pin_code = :pin_code ');
        $stmt->execute([
            ':id' => $id,
            ':email' => $email,
            ':pin_code' => $pin_code
        ]);
        if($stmt->rowCount()){
            $stmt = $this->connection()->prepare('UPDATE users SET active = 1,reason= :reason,activated_by = :activated_by WHERE id = :id');
            $stmt->execute([
                ':reason' => $reason,
                ':activated_by' => $activated_by,
                ':id' => $id
            ]);
            return ['true','User has been Activated Successfully'];
        }
        return ['false','Please Stop messing around & Let The Hidden Fields'];
        
    }
    public function login($username,$password){
        $this->username = $username;

        $this->password = (is_array($password)) ? $password[1] : $password;
        

        
       
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE username = :username OR email = :username ');
        $stmt->execute([
            ':username' => $this->username,

            
            
        ]);

        if($stmt->rowCount()){
            
            while($extract = $stmt->fetch(PDO::FETCH_ASSOC) ){


                    if(password_verify($this->password,$extract['password'])){

                        if($extract['last_log'] === NULL){
                            $stmt = $this->connection()->prepare('UPDATE  users  SET last_log =  :last_log WHERE username = :username OR email = :username ');
                            $stmt->execute([
                                ':last_log' => date('Y-m-d H:i:s'),
                                ':username' => $this->username
                                
                            ]);
                        }else{

                            $stmt = $this->connection()->prepare('UPDATE  users SET  last_log = :last_log , is_logged = :is_logged WHERE username = :username or email = :username ');
                            $stmt->execute([
                                ':last_log' => date('Y-m-d H:i:s'),
                                ':username' => $this->username,
                                'is_logged' => TRUE
                            ]);
                        }
                            return true;
                    }else{
                        $error[] = 'Incorrect Password';
                    }
                  
            }   
        }else{
           if(preg_match('/^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$/',$username)){
            
            $error[] = 'Incorrect Username';
           }else{
            $error[] = 'Incorrect Email Address';
           }
        }
        return['false',$error];
    }
    public function isLoggedIn($username){
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE username = :username AND is_logged = 1 AND active = 1');
        $stmt->execute([
            ':username' => $username
        ]);
        return ($stmt->rowCount()) ?: false;

    }
    public function register($FL_name,$username,$password,$department,$year,$email){
       
        
        $stmt = $this->connection()->prepare('SELECT * FROM users WHERE username = :username OR email = :email');
        $stmt->execute([
            ':username' => $username,
            ':email'    => $email
        ]);
        
        if($stmt->rowCount()){
            $register = ['false','This Username Or Email Already Exists, Please Pick up another one'];

        }else{
            $stmt = $this->connection()->prepare("INSERT INTO users (`id`,`username`,`password`,`email`,`FL_name`,`department`,`year`) VALUES (:id,:username,:password,:email,:FL_name,:department,:year)");

            while(!$stmt->rowCount()){
            
                $stmt->execute([
                    ':id' => uniqid('',true), 
                    ':username' => $username,
                    ':password' => password_hash($password,PASSWORD_DEFAULT,['cost' => 12]),
                    ':email'    => $email,
                    ':FL_name'    => $FL_name,
                    ':department' => $department,
                    ':year'      => $year,
                ]);
               
                if($stmt->rowCount()){
                    $register = ['true','Registered Successfully'];
                    
                }else{

                   $register =  ['false','Please Pick up Another Username or Email ',$this->connection()->errorCode()];
                   break;
                }
            }
        }
        return $register;
    }

    public function activateUser()
    {
        
    }

    public function view_not_approved($subject){
        $stmt = $this->connection()->prepare('SELECT * from communication WHERE approved = 0 AND subject = :subject');
        $stmt->execute([
            'subject' => $this->subject
        ]);
        return ($stmt->rowCount()) ? $stmt->fetchAll(PDO::FETCH_ASSOC) : false;

    }
    public function view_approved($subject){
        $this->subject = $subject;
        $stmt = $this->connection()->prepare('SELECT * FROM communication WHERE approved = 1 AND subject = :subject');
        $stmt->execute([
            'subject' => $this->subject
        ]);
        return ($stmt->rowCount()) ? $stmt->fetchAll(PDO::FETCH_ASSOC) : false;
    }
    public function approve($username,$id){
        $this->username = $username;
        $this->id = $id;
        $stmt = $this->connection()->prepare('UPDATE communication set approved = 1 WHERE id = :id');
        $stmt->execute([
            'id' => $this->id
        ]);
        //select insert statement
        $stmt = $this->connection()->prepare('SELECT * from users WHERE username = :username');
        $stmt->execute([
            ':username' => $this->username
        ]);
        if($stmt->rowCount()){

            foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $key => $value){
               
                $stmt = $this->connection()->prepare('UPDATE communication set user_approved = :user_approved , user_id = :user_id');
                $stmt->execute([
                    ':user_approved'  => $value['username'],
                    ':user_id'        => $value['id']
                ]);
              
            }

        }
       return false;
    }
    public function delete_post($id){
        $this->id = $id;
        $stmt = $this->connection()->prepare('DELETE FROM communication WHERE id = :id');
        $stmt->execute([
            'id' => $this->id
        ]);
        return ($stmt->rowCount()) ?: false;
        //unlink the file from the files..

    }
    public function listCommunication(){
        $stmt = $this->connection()->prepare('SELECT * FROM communication');
        $stmt->execute();
        return ($stmt->rowCount()) ? $stmt->fetchAll(PDO::FETCH_ASSOC) : false;

    }
    public function logout($username){
        $stmt = $this->connection()->prepare('UPDATE users set is_logged = 0 WHERE username = :username or email  = :email');
        $stmt->execute([

            ':username' => $username,
            ':email'    => $username
        ]);        
    }
    public function UpdatedPage(){
        $stmt = $this->connection()->prepare('SELECT * FROM pages');
        $stmt->execute();
        if($stmt->rowCount()){
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $key => $value) {
                   
                $need_to_hash = file_get_contents($value['page_name']);     
                if(password_verify($need_to_hash,$value['page_hash'])){
                    echo 'They are the same';
                }else{
                    $stmt = $this->connection()->prepare("UPDATE pages SET page_hash = :page_hash,page_updated = :page_updated WHERE id =:id ");
                    $stmt->execute([
                        ':page_hash' => password_hash($need_to_hash,PASSWORD_DEFAULT),
                        ':id'        => $value['id'],
                        ':page_updated' =>  date('Y-m-d H:i:s')
                    ]);
                    if($stmt->rowCount()){
                        echo 'They are updated successfully';
                    }
                }
            }              
        }
    }
    public function getDepartment($username){
        $stmt = $this->connection()->prepare('SELECT department,year FROM users WHERE username = :username or email = :username ');
        $stmt->execute([
            ':username' => $username
        ]);
        if($stmt->rowCount()){    
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $key => $value) {
                return ['true',$value];
                die();
            }
            
        }
        return false;
    }
    public function listdataofdepartment($username){
           
        if ($this->getDepartment($username)[1]['department'] === 'Communication') {

            $stmt = $this->connection()->prepare('SELECT * FROM communication WHERE approved = 0');
            $stmt->execute();
                
            if($stmt->rowCount()){

                return $stmt->fetchAll(PDO::FETCH_ASSOC);

            }
        }elseif($this->getDepartment($username)[1]['department'] === 'Civil'){
            $stmt = $this->connection()->prepare('SELECT * FROM civil');
            $stmt->execute();
            if($stmt->rowCount()){

                return $stmt->fetchAll(PDO::FETCH_ASSOC);

            }
        }
        return false;

    }


}
//echo $new->register('Ahmed Osama El Morsy','Mohammed_osama!','CobaltStrike','Communication','1','mohammed.osama314@gmail.com')[1];