<?php
session_start();
require_once 'operations.php';
require_once 'validation.php';

$v = new Validation;
$operations = new Operations;
if(!empty($_POST)){
    
    if(isset($_POST['Login'])){
        if(isset($_POST['LoginEmail'],$_POST['LoginPassword'])){
            print_r($v->validating_email($_POST['LoginEmail']));
            print_r($v->validating_alnum($_POST['LoginEmail']));
            if((!is_array($v->validating_alnum($_POST['LoginEmail'])))){

                if($v->validating_password($_POST['LoginPassword'])[0]){
                   
                    if(!is_array($operations->login($_POST['LoginEmail'],$_POST['LoginPassword']))){
                        $_SESSION['login'] = true;
                        $_SESSION['username'] = $_POST['LoginEmail'];
                        die('Logged in Successfully');
                        //header to admin panel
                        
                    }else{
                       
                    }
                   
                }
               
            }elseif((!is_array($v->validating_email($_POST['LoginEmail'])))){
                if($v->validating_password($_POST['LoginPassword'])[0]){
                   
                    if(!is_array($operations->login($_POST['LoginEmail'],$_POST['LoginPassword']))){
                        $_SESSION['login'] = true;
                        $_SESSION['username'] = $_POST['LoginEmail'];
                       
                        //header to admin panel with moderator access only
                        
                    }else{
                       
                    }
            }
          }
        }
    }
    if(isset($_POST['Register'])){
        if(isset($_POST['RegisterSpecialty'],$_POST['RegisterEmail'],$_POST['RegisterPassword'],$_POST['RegisterConfirmPassword'],$_POST['RegisterYearEducation'],$_POST['First_Name'],$_POST['Username'])){

                if(!is_array($v->validating_string($_POST['First_Name']))){
                    if(!is_array($v->validating_string($_POST['Last_Name']))){
                        if(!is_array($v->validating_username($_POST['Username']))){
                            if(!is_array($v->validating_email($_POST['RegisterEmail']))){
                                if(is_array($v->validating_password($_POST['RegisterPassword'])) && ($v->validating_password($_POST['RegisterPassword'])[0])){
                                    if(!is_array($v->check_password($_POST['RegisterConfirmPassword']))){
                                        if(!is_array($v->validating_Specialty($_POST['RegisterSpecialty']))){
                                           if(!is_array($v->validating_year($_POST['RegisterYearEducation']))){
                                              if( $operations->register($_POST['First_Name'] . ' '. $_POST['Last_Name'], $_POST['Username'],$_POST['RegisterPassword'],$_POST['RegisterSpecialty'], $_POST['RegisterYearEducation'],$_POST['RegisterEmail'])[0] == 'true'){
                                                    die('Registered Successfully');
                                                    //email activation
                                              }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
        }
    }
}
?>

<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>DayDay</title>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/animate.min.css" rel="stylesheet">
    <link href="assets/css/timeline.css" rel="stylesheet">
    <link href="assets/css/login_register.css" rel="stylesheet">
    <link href="assets/css/forms.css" rel="stylesheet">
    <link href="assets/css/buttons.css" rel="stylesheet">
    <script async="" src="https://www.google-analytics.com/analytics.js"></script><script src="assets/js/jquery.1.11.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/custom.js"></script>
    
  </head>
  <body marginwidth="0">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-fixed-top navbar-transparent" role="navigation">
        <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button id="menu-toggle" type="button" class="navbar-toggle">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar bar1"></span>
            <span class="icon-bar bar2"></span>
            <span class="icon-bar bar3"></span>
          </button>
          <a class="navbar-brand" href="index.php">Edu Theater</a>
        </div>
      </div>
    </nav>
    <div class="wrapper" style="min-height: 100%;">
      <div class="parallax filter-black">
          <div class="parallax-image"></div>             
          <div class="small-info">
            <div class="col-sm-10 col-sm-push-1 col-md-6 col-md-push-3 col-lg-6 col-lg-push-3">
              <div class="card-group animated flipInX">
                <div class="card">
                  <div class="card-block">
                    <div class="center">
                      <h4 class="m-b-0"><span class="icon-text">Login</span></h4>
                      <p class="text-muted">Access your account</p>
                    </div>
                    <form action="<?= htmlentities($_SERVER['PHP_SELF'],ENT_QUOTES,'UTF-8'); ?>" method="POST">
                      <div class="form-group">
                        <input type="text" class="form-control" placeholder="Email Address or Username" name="LoginEmail" value="<?= isset($_POST['LoginEmail']) ? htmlentities($_POST['LoginEmail'],ENT_QUOTES,'UTF-8'): ''; ?>">
                        <?php 
                            if(isset($_POST['LoginEmail'])){
                              switch($_POST['LoginEmail']){
                                case (is_array($v->validating_email($_POST['LoginEmail']))):
                                  echo $v->validating_email($_POST['LoginEmail'])[1];
                                break;
                                case(is_array($v->validating_alnum($_POST['LoginEmail']))):
                                  echo $v->validating_alnum($_POST['LoginEmail'])[1];
                                break;
                              }
                            }
                        ?>

                      </div>
                      <div class="form-group">
                        <input type="password" class="form-control" placeholder="Password" name="LoginPassword"/>
                        <?php 
                            if(isset($_POST['LoginPassword']) && is_array($v->validating_password($_POST['LoginPassword']))){

                                if(($v->validating_password($_POST['LoginPassword'])[0]) == 'false'){
                                    echo '<h6 style="color:red;">' . $v->validating_password($_POST['LoginPassword'])[1] . '</h6>';
                                }
                            }
                        ?>
                        
                        <a href="forget.php" class="pull-xs-right">
                          <small>Forgot?</small>
                        </a>
                        <div class="clearfix"></div>
                      </div>
                      <div class="center">
                        <button type="submit" class="btn btn-azure" name="Login">Login</button>
                      </div>
                    </form>
                  </div>
                </div>
                <div class="card">
                  <div class="card-block center">
                    <h4 class="m-b-0">
                      <span class="icon-text">Sign Up</span>
                    </h4>
                    <p class="text-muted">Create a new account</p>
                    <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
                     
                      <div class="form-group">
                        <input type="text" class="form-control" placeholder="First Name" name="First_Name" value="<?= isset($_POST['First_Name']) ? htmlentities($_POST['First_Name'],ENT_QUOTES,'UTF-8'): ''; ?>">
                        <?php 
                            if(isset($_POST['First_Name']) && is_array($v->validating_string($_POST['First_Name']))){

                                if(($v->validating_string($_POST['First_Name'])[0]) == 'false'){
                                    echo '<h6 style="color:red;">' . $v->validating_string($_POST['First_Name'])[1] . '</h6>';
                                }
                            }
                        ?>
                      </div>
                      <div class="form-group">
                        <input type="text" class="form-control" placeholder="Surname" name="Last_Name" value="<?=isset($_POST['Last_Name']) ? htmlentities($_POST['Last_Name'],ENT_QUOTES,'UTF-8'): ''; ?>">
                        <?php 
                            if(isset($_POST['Last_Name']) && is_array($v->validating_string($_POST['Last_Name']))){

                                if(($v->validating_string($_POST['Last_Name'])[0]) == 'false'){
                                    echo '<h6 style="color:red;">' . $v->validating_string($_POST['Last_Name'])[1] . '</h6>';
                                }
                            }
                        ?>
                      </div>
                      <div class="form-group">
                        <input type="text" class="form-control" placeholder="Username" name="Username" value="<?= isset($_POST['Username']) ? htmlentities($_POST['Username'],ENT_QUOTES,'UTF-8'): '';?>" >
                        <?php 
                            if(isset($_POST['Username']) && is_array($v->validating_username($_POST['Username']))){

                                if(($v->validating_username($_POST['Username'])[0]) == 'false'){
                                    echo '<h6 style="color:red;">' . $v->validating_username($_POST['Username'])[1] . '</h6>';
                                }
                            }
                        ?>
                      </div>
                      <div class="form-group">
                        <input type="email" class="form-control" placeholder="Email" name="RegisterEmail" value="<?= isset($_POST['RegisterEmail']) ? htmlentities($_POST['RegisterEmail'],ENT_QUOTES,'UTF-8'): ''; ?>">
                            <?php 
                            if(isset($_POST['RegisterEmail']) && is_array($v->validating_email($_POST['RegisterEmail']))){

                                if(($v->validating_email($_POST['RegisterEmail'])[0]) == 'false'){
                                    echo '<h6 style="color:red;">' . $v->validating_email($_POST['RegisterEmail'])[1] . '</h6>';
                                }
                            }
                        ?>
                      </div>
                      <div class="form-group">
                        <input type="password" class="form-control" placeholder="Password" name="RegisterPassword">
                            <?php 
                            if(isset($_POST['RegisterPassword']) && is_array($v->validating_password($_POST['RegisterPassword']))){

                                if(($v->validating_password($_POST['RegisterPassword'])[0]) == 'false'){
                                    echo '<h6 style="color:red;">' . $v->validating_password($_POST['RegisterPassword'])[1] . '</h6>';
                                }
                            }
                        ?>
                      </div>
                      <div class="form-group">
                        <input type="password" class="form-control" placeholder="Confirm Password" name="RegisterConfirmPassword">
                            <?php 

                            if(isset($_POST['RegisterConfirmPassword']) && is_array($v->check_password($_POST['RegisterConfirmPassword']))){

                                if(($v->check_password($_POST['RegisterConfirmPassword'])[0]) == 'false'){
                                    echo '<h6 style="color:red;">' . $v->check_password($_POST['RegisterConfirmPassword'])[1] . '</h6>';
                                }
                            }
                        ?>
                      </div>
                      <div class="form-group">
                       <input type='text' placeholder = 'Enter your Specailty' class ='form-control' name='RegisterSpecialty' value="<?= isset($_POST['RegisterSpecialty']) ? htmlentities($_POST['RegisterSpecialty'],ENT_QUOTES,'UTF-8'): '';?>"/>
                           
                        <?php 
                            
                            
                           if(isset($_POST['RegisterSpecialty']) && is_array($v->validating_Specialty($_POST['RegisterSpecialty']))){

                                if(($v->validating_Specialty($_POST['RegisterSpecialty'])[0]) == 'false'){
                                    echo '<h6 style="color:red;">' . $v->validating_Specialty($_POST['RegisterSpecialty'])[1] . '</h6>';
                                }
                            }
                        ?>
                       
                      </div>
                      <div class="form-group">
                        <input type="text" class="form-control" placeholder="Year , Example : 0,1,2,3,4 " name="RegisterYearEducation" value="<?= isset($_POST['RegisterYearEducation']) ? htmlentities($_POST['RegisterYearEducation'],ENT_QUOTES,'UTF-8'): ''; ?>">
                        <?php 
                            if(isset($_POST['RegisterYearEducation']) && is_array($v->validating_year($_POST['RegisterYearEducation']))){

                                if(($v->validating_year($_POST['RegisterYearEducation'])[0]) == 'false'){
                                    echo '<h6 style="color:red;">' . $v->validating_year($_POST['RegisterYearEducation'])[1] . '</h6>';
                                }
                            }
                        ?>
                      </div>
                      
                      <button type="submit" class="btn btn-azure" name='Register'>Register</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>

      <footer class="footer">
        <div class="container">
          <p class="text-muted"> Copyright © EduTheater - All rights reserved  </p>
        </div>
      </footer>

    </div>
  

</body></html>
