<?php   
require_once 'Database_Model.php';
class file_upload{
    private $file_ext,$file_size,$file_name_new,$file_destination,$file_name,$file_temp,$user_file_name,$file_check;
    public $error,$filename_test,$data_type,$year,$subject,$user_uploaded,$department,$SL;
    public $term = 'second_term';

  
    private $mime_type = ['png','jpeg','jpg','pdf'];

    const CREDENTIALS = [
        'username'  =>  'root',
        'password'  => '',
        'dbname'    => 'edutheater',
        'host'      => 'localhost'
    ];
    
    protected static $pdo = null;
        
    public function connection(){
        try 
        {
            if (NULL === self::$pdo)
            {
                self::$pdo = new \PDO('mysql:host='. self::CREDENTIALS['host']. ';dbname='.self::CREDENTIALS['dbname'],self::CREDENTIALS['username'],self::CREDENTIALS['password']);
            }
            return self::$pdo;
        }
        catch(PDOException $e)
        {
            die($e->getMessage());
        }
    }

  
    public function not_empty($data){
        return (!empty($data)) ?: false;
    }
    public function upload($file,$department,$username,$subject,$year,$SL){
        $this->subject = $subject;
        $this->username = $username;
        $this->department = $department;
        $this->year       = $year;
        $this->SL       = $SL;


        
        if($this->not_empty($file)){
            
            $this->file_name = $file['name'];
        
          


            
                $this->user_file_name = $this->file_name;
                $this->filename_test  = $this->file_name;
                $this->filename_test  = pathinfo($this->filename_test, PATHINFO_FILENAME);
                
                $this->allowed_length($this->filename_test);
                
                $this->getFileName($this->filename_test);

                
                
                if(!($file['type'] === NULL)){

                    $this->file_ext = explode('/',$file['type']);

                    $this->file_ext = $this->file_ext[1];
                    

                    $this->file_size = $file['size'];
                    $this->DataSize($this->file_size);
                   
                    
                }else{
                 $this->error[] = 'Invalid Type';
                }


               if(empty($this->error)){
                    $this->file_name_new = uniqid('',true).'.'.$this->file_ext;
                    $this->file_temp     = $file['tmp_name'];

                    $this->file_destination = dirname(realpath(__DIR__)) . '/edutheater/uploads/' . $this->department  .'/'. $this->year. '/' . $this->term . '/' . $this->subject . '/'. $this->SL . '/' . $this->file_name_new;
                    $this->move_file($this->file_temp);
                    //$subject, int $year,$data_type,$term

                    $this->insert_file($this->subject, $this->year , $this->SL,'second_term',$this->username);
                     
                    $this->file_check = mime_content_type($this->file_destination);

                    $this->file_check = explode('/',$this->file_check);
                   
                    if(!in_array($this->file_check[1],$this->mime_type)){
                        if($this->file_check === 'empty'){
                                     
                            $this->error[] = 'An Empty file Is not allowed :) ';
                            unlink($this->file_destination);
                           
                        }else{
                            $this->error[] = 'That is a fake file containing of ' . $this->file_check[1] . ' Data :) , Try Harder';
                            
                            unlink($this->file_destination);
                        }
                    
                    }
                    

                    if(empty($this->error)){
                        echo 'Operation Has been done succesfully';
                    }else{

                        if(is_array($this->error)){

                                            
                            foreach ($this->error as  $value) {
                        
                                echo $value;
                              
                                break;
                            }
                        }else{
                            echo $this->error;
                             
                        }
                    }
                }else{
                    foreach($this->error as $value){
                      $array[] = $value;
                      

                      
                        if(is_array($array)){
                            
                            foreach($array as $value1){
                                echo $value1;

                                break 2;
                            }
                        }else{
                            echo $array[0];
   
                        }
                        
                    }
                }
            
        }
    }
    public function allowed_length($length){
        return ((strlen($length) >= 8) && (strlen($length) <= 64)) ?: $this->error[] = 'Allowed file name length is 8 - 64 characters';
    }
    
    public function noError(){
        return ($this->file_eror === 0) ? true : $this->error[] = 'An Error Has Occured While Uploading, Please Try Again';
    }
    public function move_file($file_tmp){
        return move_uploaded_file($file_tmp, $this->file_destination) ?: $this->error[] = 'Failed To move the file, Please contact the Admin';
    }
    public function getFileName($file){
        $file = $this->filename_test;
        
        
        return (ctype_alnum($this->filename_test)) ? str_replace(['!','@','#','$','%','^','&','*','(',')','_','+','=','-',',','~','<','>','\\','/','script',' ','0','0x','alert','cookie'], '',strtolower(htmlentities($file,ENT_QUOTES,'UTF-8'))) : $this->error[] = 'File should only contain of letters and numbers only';
       
    }
    public function insert_file($subject, $year,$data_type,$term,$username){
        $this->subject = $subject;
        $this->year    = $year;
        $this->data_type = $data_type;
        $this->term     = $term;
        $stmt = $this->connection()->prepare('INSERT INTO communication (`id`,`subject`,`time_uploaded`,`user_uploaded`,`approved`,`year`,`destination`,`user_file_name`,`hashed_name`,`file_name`,`data_type`) VALUES(:id,:subject,:time_uploaded,:user_uploaded,:approved,:year,:destination,:user_file_name,:hashed_name,:file_name,:data_type)');
        while(!$stmt->rowCount()){
            $stmt->execute([
                ':id'            => uniqid('',true),
                ':subject'       => $this->subject,
                ':time_uploaded' => date('Y-m-d H:i:s'),
                ':user_uploaded' => $this->username,
                ':approved'      => 0,
                ':year'          => $this->year,
                ':destination'   => $this->file_destination,
                ':user_file_name'=> openssl_encrypt($this->user_file_name, 'AES-256-ECB', '!@#$%^&*()_+'),
                ':hashed_name'   => uniqid('',true).'.'.$this->file_ext,
                ':file_name'     => $this->getFileName($this->file_name),
                ':data_type'     => $this->SL
            ]);
        }
       
        return ($stmt->rowCount()) ?: $this->error[] = 'Failed To Finish up your operation, Please Contact The Admin';
    }
    public function DataType  ($DataType){
        return in_array($DataType,$this->mime_type) ?: $this->error[] = 'Invalid data type';
    }
    public function DataSize($DataName){
        switch($DataName){
            case ($this->file_ext === 'png'):
            case ($this->file_ext === 'jpg'):
            case ($this->file_ext === 'jpeg'):
            return ($DataName < (3*1024*1024)) ?:  $this->error[] = $this->getSize($DataName)[0] . $this->getSize($DataName)[1] . ' is not Allowed';
            break;
            case ($this->file_ext === 'pdf'):
            return ($DataName < (15*1024*1024)) ?:  $this->error[] = $this->getSize($DataName)[0] . $this->getSize($DataName)[1] . ' is not Allowed'; 
            break;
        }
        
        
    }
    public function getSize($DataName){
        $Type = NULL;
        switch ($DataName) {
            case (($DataName /(1024*1024))  > 1024):
                $size = ceil($DataName/ (1024*1024*1024));
                $Type = [$size,'GB'];
            break;
            case(($DataName) /(1024) > 1024):
               $size = ceil($DataName/(1024*1024));
                $Type = [$size,'MB'];
            break;
            default:
                $size = ceil($DataName/1024);
                $Type = [$size,'KB'];
            break;
        }
        return $Type;
    }
}