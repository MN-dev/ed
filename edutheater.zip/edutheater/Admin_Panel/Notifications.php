<?php 
require_once 'sidebar.php';
?>
<div class="row">
	<div class="col-lg-12">
		<h2>Notifications</h2>
	</div>
	
	
	<div class="col-lg-12">
		<div class="panel panel-success">
			<div class="panel-heading">
				Success Panel
			</div>
			<div class="panel-body">
				<div class ='col-lg-12'>
		<table class="table table-striped">
  			<thead>
    			<tr>
      				<th>#</th>
      				<th>Post Name</th>
				    <th>Modified/Created Date</th>
				    <th>Modified/Created by </th>
				    <th>View Post</th>
    			</tr>
  			</thead>
  			<tbody>
    			<tr>
      				<th scope="row">1</th>
      				<td>Index</td>
      				<td>Today</td>
      				<td>Mohammed</td>
      				<td><a href ='#'>View</a></td>
    			</tr>
  			</tbody>
		</table>
	</div>					
			</div>
		</div>
	</div>
	
</div><!-- /.row -->
	
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-info">
			<div class="panel-heading">
				Info Panel
			</div>
			<div class="panel-body">
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque ut ante in sapien blandit luctus sed ut lacus. Phasellus urna est, faucibus nec ultrices placerat, feugiat et ligula. Donec vestibulum magna a dui pharetra molestie. Fusce et dui urna.</p>
			</div>
		</div>
	</div>

	<div class="col-lg-12">
		<div class="panel panel-warning">
			<div class="panel-heading">
				Warning Panel
			</div>
			<div class="panel-body">
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque ut ante in sapien blandit luctus sed ut lacus. Phasellus urna est, faucibus nec ultrices placerat, feugiat et ligula. Donec vestibulum magna a dui pharetra molestie. Fusce et dui urna.</p>
			</div>
		</div>
	</div>

	<div class="col-lg-12">
		<div class="panel panel-danger">
			<div class="panel-heading">
				Danger Panel
			</div>
			<div class="panel-body">
				<div class ='col-lg-12'>
		<table class="table table-striped">
  			<thead>
    			<tr>
      				<th>#</th>
      				<th>Page Name</th>
				    <th>Last Error Date</th>
				    
				    
    			</tr>
  			</thead>
  			<tbody>
    			<tr>
      				<th scope="row">1</th>
      				<td>Index</td>
      				<td>Today</td>
      				
    			</tr>
  			</tbody>
		</table>
	</div>					
			</div>
		</div>
	</div>
	
</div><!-- /.row -->
		
			
		
			
		
</div><!--/.main-->

	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	
	
</body>

</html>
