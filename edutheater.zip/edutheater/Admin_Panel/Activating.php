<?php 
require_once 'sidebar.php';
?>
        
        
        

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">Posts</div>
            <div class="panel-body">
                <?php

                    if(!empty($_POST['user_email']) && !empty($_POST['user_id']) && !empty($_POST['Activate']) && !empty($_POST['reason'])){
                        if($V->validating_PIN($_POST['pin_code']) && $V->validating_email($_POST['user_email'])){
                            $stmt = $O->connection()->prepare('SELECT * FROM users WHERE email = :email AND pin_code = :pin_code');
                            $stmt->execute([
                                ':email' => $_POST['user_email'],
                                ':pin_code' => $_POST['pin_code']
                            ]);
                            if(!$stmt->rowCount()){
                                echo 'Invalid PIN Code,try again';
                            }else{

                               
                                    if($V->validating_email($_POST['user_email']) && $V->validating_string($_POST['user_id']) && $V->validating_reason($_POST['reason'])[0] && $V->validating_PIN($_POST['pin_code'])){
                                        echo $O->checkUserToActivate($_POST['user_id'],$_POST['user_email'],$_SESSION['FL_name'],$_POST['pin_code'],$_POST['reason'])[1];
                                        
                                    }

                                
                            }
                        }
                    }

                ?>

            <form action="<?= htmlentities($_SERVER['PHP_SELF'],ENT_QUOTES,'UTF-8'); ?>" method="POST">
              <div class="form-group">

              <input type='text' name='reason' placeholder="Enter A reason Here For Activating The User" class="form-control" required="required">
                <?php 
                    if(isset($_POST['reason'])){
                        echo $V->validating_reason($_POST['reason'])[1];
                    }

                ?>
              </div>
               <div class="form-group">

              <input type='text' name='pin_code' placeholder="Enter The PIN Code For The User You are trying to activate" class="form-control" required="required">
                     <?php 
                    if(isset($_POST['pin_code'])){
                        echo $V->validating_PIN($_POST['pin_code'])[1];
                    }

                ?>                     

                
              </div>
                <table data-toggle="table"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc"  id="table-style" data-row-style="rowStyle">
                    <thead>
                    <tr>
                        <th data-field="name" data-sortable="true" >Username </th>
                        <th data-field="email" data-sortable="true" >E-mail </th>
                        <th data-field="date"  data-sortable="true">Joined Date</th>
                        <th data-field="Name" data-sortable="true">Last Login Date</th>
                        <th data-field="Department" data-sortable="true" >Department</th>
                        <th data-field="Education" data-sortable="true" >Year</th>
                        <th data-field="Rank" data-sortable="true" >Rank</th>
                        <th data-field="DeActivatedBy" data-sortable="true" >Deactivated By</th>
                        <th data-field="Duration" data-sortable="true" >Duration </th>
                        <th data-field="Reason" data-sortable="true" >Reason </th>

                        <th data-field="Approval">Activate User</th>
                       
                        
                      
                    </tr>
                    </thead>
                    <tbody>

                      
                            <?php
                                if($A->listDeactivatedUsers()){


                                foreach($A->listDeactivatedUsers() as $key => $value){
                                    
                                    ?>
                                    <tr>
                                    <td> <?= $value['FL_name']; ?></td>
                                    <td> <?= $value['email']; ?></td>
                                    <td><?= $value['join_date']; ?></td>
                                    <td><?= $value['last_log']; ?></td>
                                    <td><?= $value['department']; ?></td>
                                    <td><?= $value['year']; ?></td>

                                    <?php 
                                       
                                    switch($value['is_admin']){
                                        case($value['is_admin'] === 0):
                                        ?>
                                        <td>Normal User</td>
                                        <?php
                                        break;
                                        case($value['is_admin'] === 2 ):
                                        ?>
                                        <td>Manager</td>
                                        <?php
                                        break;
                                    }
                                    ?>
                                    <td><?= $value['deactivated_by']; ?></td>
                                    <td><?= $value['duration'] . ' minutes'; ?></td>
                                    <td><?= $value['reason']; ?></td>
                                    <td><div class="form-group"><input type='submit' class="form-control" name='Activate' value="Activate">
                                        <input type='hidden' name='user_id' value="<?= $value['id']; ?>">
                                        <input type='hidden' name='user_email' value="<?= $value['email']; ?>">
                                    </div></td>
                                    
                                    </tr>
                                 <?php
                                }
                            } 
                                

                            ?>
                    </tbody>
                </table>
            </form>
            </div>
        </div>
    </div>
</div><!--/.row-->  
        
               
        
                        <script>
                            $(function () {
                                $('#hover, #striped, #condensed').click(function () {
                                    var classes = 'table';
                        
                                    if ($('#hover').prop('checked')) {
                                        classes += ' table-hover';
                                    }
                                    if ($('#condensed').prop('checked')) {
                                        classes += ' table-condensed';
                                    }
                                    $('#table-style').bootstrapTable('destroy')
                                        .bootstrapTable({
                                            classes: classes,
                                            striped: $('#striped').prop('checked')
                                        });
                                });
                            });
                        
                            function rowStyle(row, index) {
                                var classes = ['active', 'success', 'info', 'warning', 'danger'];
                        
                                if (index % 2 === 0 && index / 2 < classes.length) {
                                    return {
                                        classes: classes[index / 2]
                                    };
                                }
                                return {};
                            }
                        </script>
                    </div>
                </div>
            </div>
        </div><!--/.row-->  
        
        
    </div><!--/.main-->

    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  
  
    <script src="js/bootstrap-table.js"></script>
    <script>
        !function ($) {
            $(document).on("click","ul.nav li.parent > a > span.icon", function(){        
                $(this).find('em:first').toggleClass("glyphicon-minus");      
            }); 
            $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
        }(window.jQuery);

        $(window).on('resize', function () {
          if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
        })
        $(window).on('resize', function () {
          if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
        })
    </script>   
</body>

</html>
