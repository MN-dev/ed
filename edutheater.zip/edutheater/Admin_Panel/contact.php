<?php 
require_once 'sidebar.php';
?>
<div class="row">
<div class="col-lg-12">
<h1 class="page-header">Widgets</h1>
</div>
</div><!--/.row-->
					
<div class="row">
<div class="col-xs-12 col-md-6 col-lg-3">
<div class="panel panel-blue panel-widget ">
	<div class="row no-padding">
		<div class="col-sm-3 col-lg-5 widget-left">
			<svg class="glyph stroked bag"><use xlink:href="#stroked-bag"></use></svg>
		</div>
		<div class="col-sm-9 col-lg-7 widget-right">
			<div class="large">120</div>
			<div class="text-muted">New Orders</div>
		</div>
	</div>
</div>
</div>
<div class="col-xs-12 col-md-6 col-lg-3">
<div class="panel panel-orange panel-widget">
	<div class="row no-padding">
		<div class="col-sm-3 col-lg-5 widget-left">
			<svg class="glyph stroked empty-message"><use xlink:href="#stroked-empty-message"></use></svg>
		</div>
		<div class="col-sm-9 col-lg-7 widget-right">
			<div class="large">52</div>
			<div class="text-muted">Comments</div>
		</div>
	</div>
</div>
</div>
<div class="col-xs-12 col-md-6 col-lg-3">
<div class="panel panel-teal panel-widget">
	<div class="row no-padding">
		<div class="col-sm-3 col-lg-5 widget-left">
			<svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>
		</div>
		<div class="col-sm-9 col-lg-7 widget-right">
			<div class="large">24</div>
			<div class="text-muted">New Users</div>
		</div>
	</div>
</div>
</div>
<div class="col-xs-12 col-md-6 col-lg-3">
<div class="panel panel-red panel-widget">
	<div class="row no-padding">
		<div class="col-sm-3 col-lg-5 widget-left">
			<svg class="glyph stroked app-window-with-content"><use xlink:href="#stroked-app-window-with-content"></use></svg>
		</div>
		<div class="col-sm-9 col-lg-7 widget-right">
			<div class="large">25.2k</div>
			<div class="text-muted">Page Views</div>
		</div>
	</div>
</div>
</div>
</div><!--/.row-->

<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
	<div class="panel-heading"><svg class="glyph stroked email"><use xlink:href="#stroked-email"></use></svg> Contact Form</div>
	<div class="panel-body">
		<form class="form-horizontal" action="" method="post">
			<fieldset>
				<!-- Name input-->
				<div class="form-group">
					<label class="col-md-3 control-label" for="name">Name</label>
					<div class="col-md-9">
					<input id="name" name="name" type="text" placeholder="Your name" class="form-control">
					</div>
				</div>
			
				<!-- Email input-->
				<div class="form-group">
					<label class="col-md-3 control-label" for="email">Your E-mail</label>
					<div class="col-md-9">
						<input id="email" name="email" type="text" placeholder="Your email" class="form-control">
					</div>
				</div>
				
				<!-- Message body -->
				<div class="form-group">
					<label class="col-md-3 control-label" for="message">Your message</label>
					<div class="col-md-9">
						<textarea class="form-control" id="message" name="message" placeholder="Please enter your message here..." rows="5"></textarea>
					</div>
				</div>
				
				<!-- Form actions -->
				<div class="form-group">
					<div class="col-md-12 widget-right">
						<button type="submit" class="form-control">Submit</button>
					</div>
				</div>
			</fieldset>
		</form>
	</div>
</div>
				
</div>	<!--/.main-->
		  

	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	
	<script>
		

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
