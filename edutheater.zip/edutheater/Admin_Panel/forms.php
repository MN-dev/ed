<?php 
require_once 'sidebar.php';
require_once '../file_upload.php';
$F = new file_upload;
error_reporting(E_ALL);

?>
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">Upload Your File</h1>
	</div>
</div><!--/.row-->
		

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">Form Elements</div>
			<div class="panel-body">
				<div class="col-md-6">
								
						<div class="form-group">
							<?php 

								    if(!empty($_FILES) && !empty($_POST['subject']) && !empty($_POST['LS'])){
								    	
								        $F->upload($_FILES['file'],$_SESSION['department'],$_SESSION['username'],$_POST['subject'],'First_Year',$_POST['LS']);
								        
								    }   

								?>
							<form action="<?= htmlentities($_SERVER['PHP_SELF'],ENT_QUOTES,'UTF-8'); ?>" method="POST" enctype="multipart/form-data">
								<label>Upload A File</label>
								<input class="btn btn-default btn-file"  type="file" value='Upload' name='file'>

						</div>
							
						<div class="form-group">
								<label>Subject</label>
								<input class="form-control"  name="subject" placeholder="Please Enter The Subject">
						</div>

           
              
						<div class="form-group">
								<label>Data Type </label>
								<select name="LS" class="form-control" >
							        <option value="section">section</option>
							        <option value="lecture">lecture</option>
							   	</select>
						</div>
						<div class="form-group">
								<label>Description</label>
								<textarea class="form-control" rows="3"></textarea>	
							<input type="submit" name="Upload" class="form-control" value="Upload File">
						</div>
					</form>
				</div>
			</div>
		</div><!-- /.col-->
	</div><!-- /.row -->
		
</div><!--/.main-->

	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	
</body>

</html>
