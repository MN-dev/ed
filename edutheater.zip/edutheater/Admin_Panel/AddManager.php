<?php 
require_once 'sidebar.php';
?>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">Posts</div>
            <div class="panel-body">
            <?php 
            if(!empty($_POST['user_email']) && !empty($_POST['user_id']) && !empty($_POST['AddManager']) && !empty($_POST['reason'])){
                if($A->makeManager($_POST['user_email'])){
                    echo ' <h5 style="color:green;text-align:center;">User has been upgraded to Manager Rank </h5>';
                }
            }
            ?>
            <form action="<?= htmlentities($_SERVER['PHP_SELF'],ENT_QUOTES,'UTF-8'); ?>" method="POST">
                <div class="form-group"><input type='text' placeholder="Enter A reason Here" class="form-control" name='reason'>
                <?php 
                    if(isset($_POST['reason']) && empty($_POST['reason'])){
                        echo "<h4 style='color:red;'>Uhmm? What About me ? :( , I Can't go empty</h4>";
                    }
                ?>
                </div>
                <table data-toggle="table"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc"  id="table-style" data-row-style="rowStyle">
                    <thead>
                    <tr>
                        <th data-field="name" data-sortable="true" >Username </th>
                        <th data-field="date"  data-sortable="true">Joined Date</th>
                        <th data-field="Name" data-sortable="true">Last Login Date</th>
                        <th data-field="Department" data-sortable="true" >Department</th>
                        <th data-field="Education" data-sortable="true" >Year</th>
                        <th data-field="Rank" data-sortable="true" >Rank</th>
                        <th data-field="Approval">Upgrade User</th>
                      
                        
                      
                    </tr>
                    </thead>
                    <tbody>

                      
                            <?php
                                if($A->listActiveUsers()){


                                foreach($A->listActiveUsers() as $key => $value){
                                    ?>
                                    <tr>
                                    <td> <?= $value['FL_name']; ?></td>
                                    <td><?= $value['join_date']; ?></td>
                                    <td><?= $value['last_log']; ?></td>
                                    <td><?= $value['department']; ?></td>
                                    <td><?= $value['year']; ?></td>
                                    <?php 
                                       
                                    switch($value['is_admin']){
                                        case($value['is_admin'] === 0):
                                        ?>
                                        <td>Normal User</td>
                                        <?php
                                    }
                                    ?>
                                        <td>
                                            <div class="form-group"><input type='submit' class="form-control" name='AddManager' value="Make Manager">
                                                <input type='hidden' name='user_id' value="<?= $value['id']; ?>">
                                                <input type='hidden' name='user_email' value="<?= $value['email']; ?>">
                                               
                                            </div>
                                        </td>
                                    
                                   
                                
                                      </tr>
                                 <?php
                                }
                                }
                            ?>
                    </tbody>
                </table>
            </div>
            </form>
        </div>
    </div>
</div><!--/.row-->  

                <script>
                    $(function () {
                        $('#hover, #striped, #condensed').click(function () {
                            var classes = 'table';
                
                            if ($('#hover').prop('checked')) {
                                classes += ' table-hover';
                            }
                            if ($('#condensed').prop('checked')) {
                                classes += ' table-condensed';
                            }
                            $('#table-style').bootstrapTable('destroy')
                                .bootstrapTable({
                                    classes: classes,
                                    striped: $('#striped').prop('checked')
                                });
                        });
                    });
                
                    function rowStyle(row, index) {
                        var classes = ['active', 'success', 'info', 'warning', 'danger'];
                
                        if (index % 2 === 0 && index / 2 < classes.length) {
                            return {
                                classes: classes[index / 2]
                            };
                        }
                        return {};
                    }
                </script>
            </div>
        </div>
    </div>
</div><!--/.row-->  
        
        
</div><!--/.main-->

    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/chart.min.js"></script>
    <script src="js/chart-data.js"></script>
    <script src="js/easypiechart.js"></script>
    <script src="js/easypiechart-data.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/bootstrap-table.js"></script>
    <script>
        !function ($) {
            $(document).on("click","ul.nav li.parent > a > span.icon", function(){        
                $(this).find('em:first').toggleClass("glyphicon-minus");      
            }); 
            $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
        }(window.jQuery);

        $(window).on('resize', function () {
          if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
        })
        $(window).on('resize', function () {
          if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
        })
    </script>   
</body>

</html>
