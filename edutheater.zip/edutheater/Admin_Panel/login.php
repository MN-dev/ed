<?php 
ini_set('display_errors', 1);
require_once '../validation.php';
require_once '../operations.php';
session_start();
$V = new Validation;
$O = new Operations;
if(!empty($_POST['LoginPassword']) && !empty($_POST['LoginEmail'])){
    
    if(isset($_POST['Login'])){

        if(isset($_POST['LoginEmail'],$_POST['LoginPassword'])){

  
            if((!is_array($V->validating_username($_POST['LoginEmail'])))){
            	

                if($V->validating_password($_POST['LoginPassword'])[0]){
                	  
                    if(!is_array($O->login($_POST['LoginEmail'],$_POST['LoginPassword']))){
                        $_SESSION['login'] = true;
                        $_SESSION['username'] = $_POST['LoginEmail'];
                        $_SESSION['department'] = $O->getDepartment($_SESSION['username'])[1]['department'];
                        $_SESSION['Year']       = $O->getDepartment($_SESSION['username'])[1]['year'];
                       
                        header("Location : index.php");
                        
                    }else{

                      echo  '<h5 style="text-align:center;color:red;">'.$O->login($_POST['LoginEmail'],$_POST['LoginPassword'])[1][0]. '<h5>';
                    }
                   
                }
               
            }elseif((!is_array($V->validating_email($_POST['LoginEmail'])))){

                if($V->validating_password($_POST['LoginPassword'])[0] === 'true'){
                  
                   
                    if(!is_array($O->login($_POST['LoginEmail'],$_POST['LoginPassword']))){
                        $_SESSION['login'] = true;
                        $_SESSION['username'] = $_POST['LoginEmail'];
                       $_SESSION['department'] = $O->getDepartment($_SESSION['username'])[1]['department'];
                        $_SESSION['Year']       = $O->getDepartment($_SESSION['username'])[1]['year'];
                       header("Location: index.php");
                        
                    }else{
                    	
                        echo  '<h5 style="text-align:center;color:red;">'. $O->login($_POST['LoginEmail'],$_POST['LoginPassword'])[1][0] . '<h5>';
                    }
            }
          }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Forms</title>

<link href="css/bootstrap.min.css" rel="stylesheet">

<link href="css/styles.css" rel="stylesheet">

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
	
	<form action="<?= htmlentities($_SERVER['PHP_SELF'],ENT_QUOTES,'UTF-8'); ?>" method="POST">
                      <div class="form-group">
                        <input type="text" class="form-control" placeholder="Email Address or Username" name="LoginEmail" value="<?= isset($_POST['LoginEmail']) ? htmlentities($_POST['LoginEmail'],ENT_QUOTES,'UTF-8'): ''; ?>">
                        <?php 
                            if(isset($_POST['LoginEmail'])){
                            		if(preg_match('/^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$/',$_POST['LoginEmail'])){
                            			echo '<h6 style="color:red;">' .$V->validating_username($_POST['LoginEmail'])[1] .'<h6>';
                            		}elseif(filter_var($_POST['LoginEmail'],FILTER_VALIDATE_EMAIL)){
                            			echo '<h6 style="color:red;">' .$V->validating_email($_POST['LoginEmail'])[1] . '<h6>';
                            		}elseif(empty($_POST['LoginEmail'])){
                            			echo '<h6 style="color:red"> This can not be an empty field </h6>';
                            		}else{
                            			echo ' <h6 style="color:red">Please Fill in a valid username or email </h6>';
                            		}
                            		
                            		
                            		
                            		
                            }
                        ?>

                      </div>
                      <div class="form-group">
                        <input type="password" class="form-control" placeholder="Password" name="LoginPassword"/>
                        <?php 
                            if(isset($_POST['LoginPassword']) && is_array($V->validating_password($_POST['LoginPassword']))){

                                if(($V->validating_password($_POST['LoginPassword'])[0]) == 'false'){
                                    echo '<h6 style="color:red;">' . $V->validating_password($_POST['LoginPassword'])[1] . '</h6>';
                                }
                            }
                        ?>
                        
                        <a href="forget.php" class="pull-xs-right">
                          <small>Forgot?</small>
                        </a>
                        <div class="clearfix"></div>
                      </div>
                      <div class="center">
                        <button type="submit" class="btn btn-azure" name="Login">Login</button>
                      </div>
                    </form>
                  </div>
		

	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	
</body>

</html>
